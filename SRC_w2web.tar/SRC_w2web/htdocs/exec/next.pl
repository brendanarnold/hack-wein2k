#!/usr/bin/perl

require "../../libs/w2web.pl";
&GetInput;
&GetSession;

redirectURL($nexturl);


